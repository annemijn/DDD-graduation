<?php
$servername= "rdbms";
$username= "U2529504";
$password= "Db1acreations";
$database= "DB2529504";
$connection = mysqli_connect($servername,$username,$password,$database); //connectie maken met database
	if(!$connection)
	{
		echo "Connection failed! <br>";
	}
?>
