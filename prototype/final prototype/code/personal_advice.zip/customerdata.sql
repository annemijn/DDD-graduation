-- phpMyAdmin SQL Dump
-- version 4.6.4
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Gegenereerd op: 28 mei 2020 om 12:23
-- Serverversie: 5.7.14
-- PHP-versie: 5.6.25

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `loans`
--

-- --------------------------------------------------------

--
-- Tabelstructuur voor tabel `customerdata`
--

CREATE TABLE `customerdata` (
  `id` int(11) NOT NULL,
  `loanPurpose` int(11) NOT NULL DEFAULT '0',
  `loanAmount` int(11) NOT NULL DEFAULT '0',
  `monthamount` int(11) NOT NULL DEFAULT '0',
  `monthamount2` int(11) NOT NULL DEFAULT '0',
  `monthamount3` int(11) NOT NULL DEFAULT '0',
  `loanCategory` varchar(100) NOT NULL DEFAULT '0',
  `age` int(11) NOT NULL DEFAULT '0',
  `typeIncome` int(11) NOT NULL DEFAULT '0',
  `netIncome` int(11) NOT NULL DEFAULT '0',
  `agePartner` int(11) NOT NULL DEFAULT '0',
  `typeIncomePartner` int(11) NOT NULL DEFAULT '0',
  `netIncomePartner` int(11) NOT NULL DEFAULT '0',
  `children` int(11) NOT NULL DEFAULT '0',
  `province` int(20) NOT NULL DEFAULT '0',
  `consumptionValues` int(11) NOT NULL DEFAULT '0',
  `goals` int(11) NOT NULL DEFAULT '0',
  `positionProduct` int(11) NOT NULL DEFAULT '0',
  `reviewScore` int(11) NOT NULL DEFAULT '0',
  `interestRate` int(11) NOT NULL DEFAULT '0',
  `typeLoan` int(11) NOT NULL DEFAULT '0',
  `loanDuration` int(11) NOT NULL DEFAULT '0',
  `monthlyRepaymentAmount` int(11) NOT NULL DEFAULT '0',
  `reviewScore2` int(11) NOT NULL DEFAULT '0',
  `reviewScore3` int(11) NOT NULL DEFAULT '0',
  `interestRate2` int(11) NOT NULL DEFAULT '0',
  `interestRate3` int(11) NOT NULL DEFAULT '0',
  `loanDuration2` int(11) NOT NULL DEFAULT '0',
  `loanDuration3` int(11) NOT NULL DEFAULT '0',
  `highestReviewScore` int(11) NOT NULL DEFAULT '0',
  `lowestLoanDuration` int(11) NOT NULL DEFAULT '0',
  `persuasion` int(11) NOT NULL DEFAULT '0',
  `persuasion2` int(11) NOT NULL DEFAULT '0',
  `persuasion3` int(11) NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=latin1;

--
-- Gegevens worden geëxporteerd voor tabel `customerdata`
--

INSERT INTO `customerdata` (`id`, `loanPurpose`, `loanAmount`, `monthamount`, `monthamount2`, `monthamount3`, `loanCategory`, `age`, `typeIncome`, `netIncome`, `agePartner`, `typeIncomePartner`, `netIncomePartner`, `children`, `province`, `consumptionValues`, `goals`, `positionProduct`, `reviewScore`, `interestRate`, `typeLoan`, `loanDuration`, `monthlyRepaymentAmount`, `reviewScore2`, `reviewScore3`, `interestRate2`, `interestRate3`, `loanDuration2`, `loanDuration3`, `highestReviewScore`, `lowestLoanDuration`, `persuasion`, `persuasion2`, `persuasion3`) VALUES
(1, 1, 30000, 0, 0, 0, '', 34, 1, 3000, 35, 1, 2800, 1, 3, 3, 1, 0, 78, 3, 1, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(2, 3, 50000, 0, 0, 0, '', 50, 1, 3000, 0, 0, 0, 2, 4, 3, 3, 0, 78, 3, 1, 120, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(3, 4, 50000, 0, 0, 0, '', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(4, 2, 20000, 0, 0, 0, '', 21, 3, 3300, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(5, 6, 20000, 0, 0, 0, '', 55, 2, 1200, 44, 3, 2500, 1, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(6, 2, 25000, 0, 0, 0, '', 77, 2, 3000, 33, 3, 3400, 2, 10, 2, 2, 0, 74, 3, 1, 60, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(7, 1, 50000, 0, 0, 0, '', 55, 5, 3000, 0, 0, 0, 2, 8, 2, 3, 0, 77, 3, 1, 60, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(8, 1, 40000, 0, 0, 0, '', 22, 4, 1500, 0, 0, 0, 2, 9, 2, 0, 0, 77, 3, 1, 24, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(9, 1, 33000, 0, 0, 0, '', 22, 4, 3000, 0, 0, 0, 1, 9, 0, 7, 0, 77, 3, 1, 120, 150, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(10, 1, 33000, 0, 0, 0, '', 45, 1, 1500, 0, 0, 0, 1, 1, 2, 3, 0, 77, 3, 1, 120, 0, 76, 79, 4, 6, 60, 36, 79, 36, 0, 0, 0),
(11, 6, 50000, 0, 0, 0, '', 35, 1, 2500, 0, 0, 0, 2, 6, 3, 3, 0, 77, 3, 1, 120, 0, 79, 90, 4, 5, 60, 84, 90, 60, 1697, 272, 686),
(12, 4, 50000, 429, 866, 729, '0', 25, 4, 1000, 0, 0, 0, 2, 4, 1, 4, 0, 77, 3, 1, 120, 0, 79, 74, 4, 5, 60, 72, 79, 60, 65, 10, 12),
(13, 2, 25000, 214, 433, 1472, '0', 32, 1, 2500, 0, 0, 0, 2, 5, 3, 7, 0, 77, 3, 1, 120, 0, 74, 76, 4, 6, 60, 18, 77, 18, 272, 33, 39),
(14, 5, 50000, 0, 0, 0, '0', 21, 3, 3000, 44, 2, 2500, 2, 5, 3, 7, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0),
(15, 1, 33000, 283, 572, 962, '0', 21, 4, 1500, 0, 0, 0, 2, 8, 3, 7, 0, 77, 3, 1, 120, 0, 90, 74, 4, 5, 60, 36, 90, 36, 1086, 767, 135),
(20, 1, 33000, 566, 2860, 481, '0', 32, 2, 2500, 0, 0, 0, 2, 11, 3, 7, 0, 77, 3, 1, 60, 0, 74, 76, 4, 5, 12, 72, 77, 12, 1086, 135, 170);

--
-- Indexen voor geëxporteerde tabellen
--

--
-- Indexen voor tabel `customerdata`
--
ALTER TABLE `customerdata`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT voor geëxporteerde tabellen
--

--
-- AUTO_INCREMENT voor een tabel `customerdata`
--
ALTER TABLE `customerdata`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=21;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
